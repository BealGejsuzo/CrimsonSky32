import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "900"))

DEVS = list(map(int, os.getenv("DEVS", "5126860596").split()))

API_ID = int(os.getenv("API_ID", "28640268"))

API_HASH = os.getenv("API_HASH", "dc13117614817b37e2f9bf23504ff487")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8135257725:AAFXBul0SGCGXfhLb1l7rP6I96GscZT6KjE")

OWNER_ID = int(os.getenv("OWNER_ID", "5126860596"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002125842026 -1002053287763 -1002044997044 -1002022625433 -1002050846285 -1002400165299 -1002416419679 -1001473548283").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://PetraInfernox:Petra088@cluster0.9bqw9vu.mongodb.net/")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1002331639417"))